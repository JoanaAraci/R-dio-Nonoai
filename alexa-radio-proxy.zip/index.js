
const express = require("express");
const request = require("request");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());

app.get("/stream", (req, res) => {
  const streamUrl = "https://azura2.cmaudioevideo.com:8040/radio.mp3";
  req.pipe(request(streamUrl)).pipe(res);
});

app.get("/", (req, res) => {
  res.send("Alexa Rádio Proxy está rodando.");
});

app.listen(PORT, () => {
  console.log("Servidor rodando na porta " + PORT);
});
